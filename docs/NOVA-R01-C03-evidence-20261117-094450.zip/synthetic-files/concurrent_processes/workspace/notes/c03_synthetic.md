# C03 synthetic

C03 synthetic body
