﻿from pathlib import Path
import subprocess,sys,os,time,json,socket
from urllib.request import Request,urlopen
r=Path(__file__).parent
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
log=(r/'browser-api.log').open('x')
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['USERPROFILE']=str(r/'browser-home');env['HOME']=str(r/'browser-home')
server_cmd=[sys.executable,'-B',str(r/'verify_http.py'),str(r/'browser-data'),str(port),'auto']
p=subprocess.Popen(server_cmd,stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
result={}
try:
 for _ in range(100):
  try:
   with urlopen(f'http://127.0.0.1:{port}/health',timeout=1):break
  except Exception:time.sleep(.05)
 payload={'title':'Malicious <img src=x onerror="document.body.dataset.r01attacked=1">','body':'<script>document.body.dataset.r01attacked=1</script> Synthetic only'}
 with urlopen(Request(f'http://127.0.0.1:{port}/assistant/quick-note',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})) as res:
  result['http_status']=res.status;result['response']=json.load(res)
 cmd=[r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe','--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1','--user-data-dir='+str(r/'edge-profile'),'--virtual-time-budget=4000','--dump-dom',f'http://127.0.0.1:{port}/']
 edge=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
 with (r/'browser-dom.html').open('xb') as f:f.write(edge.stdout)
 with (r/'browser-stderr.txt').open('xb') as f:f.write(edge.stderr)
 dom=edge.stdout.decode('utf-8',errors='replace')
 result.update(command=cmd,exit_code=edge.returncode,escaped_payload_present='&lt;script&gt;document.body.dataset.r01attacked=1&lt;/script&gt;' in dom,executed_marker_present='data-r01attacked="1"' in dom,notes_rendered='Malicious &lt;img' in dom)
except Exception as e:result['blocked_error']=type(e).__name__+': '+str(e)
finally:
 p.terminate();p.wait(timeout=10);log.close()
 result['server_command']=server_cmd;result['server_exit_code']=p.returncode
 with (r/'browser-evidence.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['response','command','server_command']},indent=2))
