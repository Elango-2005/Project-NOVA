﻿from pathlib import Path
import sys,json,time,os,subprocess,socket,tempfile,sqlite3,hashlib
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
BASE=Path(__file__).parent
sys.path.insert(0,r'C:\NOVA\services\backend\src')
if len(sys.argv)>1:
 import uvicorn
 from nova.api.assistant_ui import build_user_friendly_assistant_app
 directory=Path(sys.argv[1]); port=int(sys.argv[2]); mode=sys.argv[3]
 app=build_user_friendly_assistant_app(data_dir=directory/'data',workspace_dir=directory/'workspace',auto_approve_reversible_local_writes=mode=='auto')
 c=app.state.nova_container
 if mode=='expire': c.permission_gate.ledger.ttl=1
 if mode=='crash':
  handler=c.tool_executor._handlers['notes.create_note']
  def crash_after_real_write(args):
   handler(args)
   os._exit(73)
  c.tool_executor.register_tool_handler('notes.create_note',crash_after_real_write)
 uvicorn.run(app,host='127.0.0.1',port=port,log_level='warning')
 sys.exit()
records=[]; outcomes=[]; processes=[]; proc=None; log=None
root=BASE/'http-data';root.mkdir()
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
def req(path,body=None):
 entry={'method':'POST' if body is not None else 'GET','path':path,'request':body}
 try:
  request=Request(f'http://127.0.0.1:{port}'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  try:
   with urlopen(request,timeout=10) as response:status=response.status;data=json.load(response)
  except HTTPError as e:status=e.code;data=json.load(e)
  entry.update(status=status,response=data);return status,data
 except Exception as e:
  entry.update(error=type(e).__name__);raise
 finally:records.append(entry)
def start(mode='ask'):
 global proc,log
 logpath=BASE/f'http-server-{len(processes)}.txt';log=logpath.open('x',encoding='utf-8')
 cmd=[sys.executable,'-B',str(Path(__file__)),str(root),str(port),mode]
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['USERPROFILE']=str(BASE/'fake-profile');env['HOME']=str(BASE/'fake-profile')
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 processes.append({'command':cmd,'pid':proc.pid,'log':str(logpath)})
 for i in range(100):
  if proc.poll() is not None:raise RuntimeError(logpath.read_text())
  try:
   if req('/health')[0]==200:return
  except (URLError,ConnectionError):pass
  time.sleep(.05)
 raise RuntimeError('startup timeout')
def stop():
 if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 if proc:processes[-1]['exit_code']=proc.returncode
 if log:log.close()
def snap(label):
 state={'files':{},'databases':{}}
 for p in (root/'workspace').rglob('*.md'):
  state['files'][str(p.relative_to(root))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'text':p.read_text(encoding='utf-8')}
 for db in (root/'data').glob('*.db'):
  conn=sqlite3.connect(db)
  try:
   tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
   state['databases'][db.name]={t:[list(row) for row in conn.execute('SELECT * FROM "'+t+'"')] for t in tables}
  finally:conn.close()
 with (BASE/f'snapshot-{label}.json').open('x',encoding='utf-8') as f:json.dump(state,f,indent=2,default=str)
 return state
def check(name,ok,**details):outcomes.append({'scenario':name,'result':'PASS' if ok else 'FAIL',**details})
def pending(path,args):
 status,data=req(path,args);card=data.get('pending_approval') or data.get('reply',{}).get('pending_approval')
 assert status==200 and card,(status,data)
 return {k:card[k] for k in ['task_id','node_id','proposal_id']}
def approve(card,value=True,**extra):return req('/assistant/approve',{**card,'approved':value,**extra})
try:
 start();before=snap('before')
 note=pending('/assistant/quick-note',{'title':'Allowed <img src=x onerror=alert(1)>','body':'Synthetic <script>window.R01_ATTACK=1</script>\nKeep — exact text'})
 check('approval required has no note side effect',not list((root/'workspace/notes').glob('*.md')))
 status,data=approve(note,arguments={'body':'changed'});check('HTTP approval arguments cannot be replaced',status==422,status=status)
 status,data=approve(note,agent_role='comms');check('HTTP role injection rejected',status==422,status=status)
 for field in ['task_id','node_id','proposal_id']:
  status,data=approve({**note,field:'forged'});check('wrong HTTP '+field,status==409,status=status)
 status,data=approve(note);check('note approval real result',status==200 and data['reply']['action_category']=='note_saved',status=status)
 status,data=approve(note);check('note approval replay',status==409,status=status)
 html=req('/')[1] if False else None
 denied=pending('/assistant/chat',{'message':'Note: Denied chat — never write this'})
 status,data=approve(denied,False);check('chat note denial',status==200 and data['reply']['action_category']=='action_failed')
 check('denied activity description truthful',not any(a['what_happened']=='Saved a personal note' and a['status']=='not_executed' for a in data['workspace']['recent_activity']),activity=data['workspace']['recent_activity'])
 event={'title':'Calendar synthetic','start_iso':'2026-11-18T10:00:00','end_iso':'2026-11-18T11:00:00'}
 card=pending('/assistant/quick-event',event)
 with ThreadPoolExecutor(max_workers=10) as pool:responses=list(pool.map(lambda _:approve(card),range(10)))
 check('concurrent calendar approvals',sum(s==200 for s,d in responses)==1,statuses=[s for s,d in responses])
 duplicate=pending('/assistant/quick-note',{'title':'Allowed <img src=x onerror=alert(1)>','body':'overwrite forbidden'})
 status,data=approve(duplicate);check('duplicate note reports failure',status==200 and data['reply']['action_category']=='action_failed')
 for invalid in ['not-a-date','2026-02-30T10:00:00','2026-11-18T11:00:00','2026-11-18T10:00:00+05:30']:
  status,data=req('/assistant/quick-event',{**event,'start_iso':invalid});check('invalid calendar '+invalid,status==200 and data['action_category']=='action_failed')
 pending_revoked=pending('/assistant/quick-event',{**event,'title':'Must not execute'})
 req('/permissions/revoke',{'tool_name':'calendar.create_event'})
 status,data=approve(pending_revoked);check('pending revocation blocks approval',status==200 and data['reply']['action_category']=='action_failed')
 saved=snap('before-restart');stop();start()
 restored=snap('after-restart');check('persisted file/calendar contents',saved['files']==restored['files'] and saved['databases']['nova_calendar.db']==restored['databases']['nova_calendar.db'])
 status,data=req('/assistant/quick-event',{**event,'title':'Revocation after restart'});check('revocation survives process restart',data['action_category']=='action_failed')
 status,data=approve(note);check('replay after process restart',status==409)
 uncertain=pending('/assistant/quick-note',{'title':'Crash after write','body':'Only one actual file write'})
 stop();start('crash')
 try:approve(uncertain);check('process interruption occurred',False)
 except (ConnectionError,URLError):proc.wait(timeout=10);check('process interruption occurred',proc.returncode==73,exit_code=proc.returncode)
 crashed=snap('crashed');stop();start()
 status,data=approve(uncertain);check('uncertain completed write replay rejected',status==409,status=status)
 after=snap('crash-restarted');check('uncertain file unchanged',crashed['files']==after['files'])
 stop();start('expire');expired=pending('/assistant/quick-note',{'title':'Expired','body':'Must not write'})
 time.sleep(1.1);status,data=approve(expired);check('real elapsed expiry',status==409 and 'expired' in str(data),status=status)
 stop();start('auto');status,data=req('/assistant/quick-note',{'title':'Auto approved','body':'Synthetic allowed local write'})
 check('permitted automatic write',status==200 and data['action_category']=='note_saved')
 req('/permissions/revoke',{'tool_name':'notes.create_note','agent_role':'coding'})
 status,data=req('/assistant/chat',{'message':'Note: Revoked chat — no bypass'});check('chat role revocation blocks write',status==200 and data['reply']['action_category']=='action_failed')
 status,data=req('/assistant/quick-note',{'title':'Revoked quick','body':'no bypass'});check('quick role revocation blocks write',status==200 and data['action_category']=='action_failed')
 final=snap('final')
 check('filesystem exact allowed writes only',len(final['files'])==3 and any('<script>window.R01_ATTACK=1</script>' in f['text'] for f in final['files'].values()),files=list(final['files']))
 conn=sqlite3.connect(root/'data/nova_calendar.db');events=conn.execute('SELECT title FROM calendar_events').fetchall();conn.close();check('calendar exactly one row',events==[('Calendar synthetic',)],rows=events)
finally:
 stop()
 with (BASE/'http-evidence.json').open('x',encoding='utf-8') as f:json.dump({'scenarios':outcomes,'requests':records,'processes':processes},f,indent=2)
print(json.dumps(outcomes,indent=2))
