﻿import sys,json,sqlite3
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,r'C:\NOVA\services\backend\src')
from nova.main import NovaRuntimeContainer
from nova.core.domain.proposals import ToolCallProposal
from nova.core.domain.primitives import AgentRole
from nova.core.orchestration.ports import ToolActionContext
from nova.core.cognition.conversation_session import PersonalAssistantChatSession
base=Path(__file__).parent
out=[]
def runtime(name):return NovaRuntimeContainer(data_dir=base/name/'data',workspace_dir=base/name/'workspace',auto_approve_reversible_local_writes=False)
def action(c,title='Synthetic'):
 p=ToolCallProposal(agent_role='coding',node_id='node_v01',thought='Verification',tool_name='notes.create_note',arguments={'title':title,'body':'Synthetic bound content'},declared_sensitivity='reversible_write',rationale='Independent challenge')
 ctx=ToolActionContext(task_id='task_v01',session_id='session_v01',node_id='node_v01',agent_role='coding')
 c.permission_gate.evaluate_tool_proposal(p,context=ctx)
 c.permission_gate.record_user_decision(p.proposal_id,True,proposal=p,context=ctx)
 stamp=c.permission_gate.evaluate_tool_proposal(p,context=ctx)
 return p,ctx,stamp
def record(name,ok,**data):out.append({'scenario':name,'result':'PASS' if ok else 'FAIL',**data})
for mutation in ['arguments','token','expired','role','context_role','task_id','session_id','node_id','tool_name','proposal_id','missing_context']:
 c=runtime('adversarial-'+mutation);p,ctx,stamp=action(c)
 if mutation=='arguments':p=p.model_copy(update={'arguments':{'title':'Changed','body':'Unauthorized'}})
 elif mutation=='token':stamp=stamp.model_copy(update={'authorization_id':'invented'})
 elif mutation=='expired':c.permission_gate.ledger.clock=lambda:stamp.expires_at+1
 elif mutation=='role':p=p.model_copy(update={'agent_role':AgentRole.COMMS})
 elif mutation=='context_role':ctx=ctx.model_copy(update={'agent_role':AgentRole.COMMS})
 elif mutation in ['task_id','session_id','node_id']:ctx=ctx.model_copy(update={mutation:'wrong'})
 elif mutation=='tool_name':p=p.model_copy(update={'tool_name':'filesystem.write_file'})
 elif mutation=='proposal_id':p=p.model_copy(update={'proposal_id':'forged'})
 else:ctx=None
 try:
  result=c.tool_executor.execute_approved_tool(p,stamp,context=ctx);error=None
 except Exception as exc:error=type(exc).__name__+': '+str(exc)
 files=list(c.notes_manager.notes_dir.glob('*.md'))
 record(mutation,error is not None and not files,error=error,file_count=len(files))
c=runtime('late-revoke');p,ctx,stamp=action(c);c.policy_store.revoke_tool('notes.create_note')
try:c.tool_executor.execute_approved_tool(p,stamp,context=ctx);error=None
except Exception as exc:error=str(exc)
record('executor rechecks revocation after approved stamp',error is not None and not list(c.notes_manager.notes_dir.glob('*.md')),error=error)
# Two runtime instances are an exploratory boundary, outside ADR single-process v1.
a=runtime('two-instances');b=runtime('two-instances');p,ctx,stamp=action(a)
b.policy_store.revoke_tool('notes.create_note')
try:result=a.tool_executor.execute_approved_tool(p,stamp,context=ctx);error=None
except Exception as exc:error=str(exc);result=None
record('exploratory: second runtime revocation is seen by first',error is not None,error=error,execution_status=result.status if result else None,files=[p.name for p in a.notes_manager.notes_dir.glob('*.md')],scope='two live containers sharing one data directory')
# Verify event-driven completion for the approved direct path.
c=runtime('events');session=PersonalAssistantChatSession(c)
card=session.submit_action('notes.create_note',{'title':'Event test','body':'Real local handler'}).pending_approval
session.resolve_approval(**{k:card[k] for k in ['task_id','node_id','proposal_id']},approved=True)
events=[e.event_type.value for e in c.event_bus.all_events() ] if hasattr(c.event_bus,'all_events') else []
record('direct approval emits completion events','tool_completed' in events and 'task_completed' in events,events=events)
with (base/'component-evidence.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
