# V03 synthetic

V03 synthetic body
