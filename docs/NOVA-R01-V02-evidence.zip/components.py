﻿import sys,json,sqlite3
from pathlib import Path
sys.path.insert(0,r'C:\NOVA\services\backend\src')
from nova.main import NovaRuntimeContainer
from nova.core.domain.proposals import ToolCallProposal
from nova.core.domain.primitives import AgentRole
from nova.core.orchestration.ports import ToolActionContext
r=Path(__file__).parent
results=[]
for case in ['original_two_runtime_exploit','forged_token','altered_body','role','task_id','session_id','node_id','expiry','replay']:
 d=r/('component-'+case)
 c=NovaRuntimeContainer(data_dir=d/'data',workspace_dir=d/'workspace',auto_approve_reversible_local_writes=False)
 other=NovaRuntimeContainer(data_dir=d/'data',workspace_dir=d/'workspace',auto_approve_reversible_local_writes=False) if case=='original_two_runtime_exploit' else None
 p=ToolCallProposal(agent_role='coding',node_id='node_v02',thought='Synthetic test',tool_name='notes.create_note',arguments={'title':'Synthetic','body':'V02_PRIVATE_BODY'},declared_sensitivity='reversible_write',rationale='Verification')
 ctx=ToolActionContext(task_id='task_v02',session_id='session_v02',node_id='node_v02',agent_role='coding')
 c.permission_gate.evaluate_tool_proposal(p,context=ctx)
 c.permission_gate.record_user_decision(p.proposal_id,True,proposal=p,context=ctx)
 stamp=c.permission_gate.evaluate_tool_proposal(p,context=ctx)
 if case=='original_two_runtime_exploit':other.policy_store.revoke_tool(p.tool_name)
 elif case=='forged_token':stamp=stamp.model_copy(update={'authorization_id':'V02_PRIVATE_TOKEN'})
 elif case=='altered_body':p=p.model_copy(update={'arguments':{'title':'Changed','body':'V02_ALTERED_SECRET'}})
 elif case=='role':p=p.model_copy(update={'agent_role':AgentRole.COMMS})
 elif case in ['task_id','session_id','node_id']:ctx=ctx.model_copy(update={case:'wrong_identity'})
 elif case=='expiry':c.permission_gate.ledger.clock=lambda:stamp.expires_at+1
 elif case=='replay':assert c.tool_executor.execute_approved_tool(p,stamp,context=ctx).status=='success'
 before={f.name:f.read_bytes().hex() for f in c.notes_manager.notes_dir.glob('*.md')}
 try:c.tool_executor.execute_approved_tool(p,stamp,context=ctx);error=None
 except Exception as e:error=type(e).__name__+': '+str(e)
 after={f.name:f.read_bytes().hex() for f in c.notes_manager.notes_dir.glob('*.md')}
 attempts=c.permission_gate.ledger.query_attempts()
 rejected=[a for a in attempts if a['outcome']=='rejected']
 secrets_absent=all(secret not in json.dumps(attempts) for secret in ['V02_PRIVATE_BODY','V02_PRIVATE_TOKEN','V02_ALTERED_SECRET'])
 results.append({'case':case,'result':'PASS' if error and after==before and len(rejected)==1 and secrets_absent else 'FAIL','error':error,'before':before,'after':after,'attempts':attempts,'secret_values_absent':secrets_absent})
with (r/'component-results.json').open('x') as f:json.dump(results,f,indent=2)
print(json.dumps([{'case':x['case'],'result':x['result']} for x in results],indent=2))
