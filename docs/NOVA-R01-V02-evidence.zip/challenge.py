﻿from pathlib import Path
import sys,json,sqlite3,subprocess,socket,time,os
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
R=Path(__file__).parent
sys.path.insert(0,r'C:\NOVA\services\backend\src')
if len(sys.argv)>1:
 import uvicorn
 from nova.api.assistant_ui import build_user_friendly_assistant_app
 from nova.main import NovaRuntimeContainer
 from nova.core.domain.events import EventType
 d=Path(sys.argv[1]);port=int(sys.argv[2]);mode=sys.argv[3]
 app=build_user_friendly_assistant_app(data_dir=d/'data',workspace_dir=d/'workspace',auto_approve_reversible_local_writes=False)
 if mode=='race':
  other=NovaRuntimeContainer(data_dir=d/'data',workspace_dir=d/'workspace',auto_approve_reversible_local_writes=False)
  def revoke_at_started(event):
   other.policy_store.revoke_tool(event.payload['tool_name'])
  app.state.nova_container.event_bus.subscribe(revoke_at_started,EventType.TOOL_STARTED)
 uvicorn.run(app,host='127.0.0.1',port=port,log_level='warning')
 sys.exit()
records=[];checks=[];runs=[]
def request(port,path,body=None):
 req=Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'})
 try:
  with urlopen(req,timeout=10) as res:status=res.status;raw=res.read().decode()
 except HTTPError as e:status=e.code;raw=e.read().decode()
 try:result=json.loads(raw)
 except ValueError:result=raw
 records.append({'port':port,'path':path,'body':body,'status':status,'response':result})
 return status,result
def check(name,ok,**details):checks.append({'name':name,'result':'PASS' if ok else 'FAIL',**details})
for mode in ['normal','race','audit_failure']:
 d=R/('challenge-'+mode)
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 cmd=[sys.executable,'-B',str(Path(__file__)),str(d),str(port),mode]
 log=(R/(mode+'-server.log')).open('x',encoding='utf-8')
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['HOME']=str(R/'profile');env['USERPROFILE']=str(R/'profile')
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 run={'command':cmd,'pid':p.pid};runs.append(run)
 try:
  for _ in range(100):
   try:
    if request(port,'/health')[0]==200:break
   except (URLError,ConnectionError):time.sleep(.05)
  body={'message':'Note: V02 chat - Synthetic local note'} if mode=='normal' else {'title':'V02 challenge','body':'Synthetic local note'}
  code,data=request(port,'/assistant/chat' if mode=='normal' else '/assistant/quick-note',body)
  card=data['reply']['pending_approval'] if mode=='normal' else data['pending_approval']
  ids={k:card[k] for k in ['task_id','node_id','proposal_id']}
  if mode=='audit_failure':
   with sqlite3.connect(d/'data/nova_audit.db') as conn:
    conn.execute("CREATE TRIGGER deny_attempt BEFORE INSERT ON authorization_attempts BEGIN SELECT RAISE(ABORT,'V02 injected audit failure'); END")
  code,result=request(port,'/assistant/approve',{**ids,'approved':True})
  _,status=request(port,'/tasks/'+ids['task_id'])
  _,sse=request(port,'/tasks/'+ids['task_id']+'/events/sse')
  ev=[json.loads(line[6:]) for line in sse.splitlines() if line.startswith('data: ')]
  names=[e['event_type'] for e in ev]
  files=[f.name for f in (d/'workspace/notes').glob('*.md')]
  with sqlite3.connect(d/'data/nova_audit.db') as conn:
   auth=conn.execute('SELECT status FROM tool_authorizations').fetchall()
   attempts=conn.execute('SELECT outcome,reason_code,trusted_context,submitted_claims FROM authorization_attempts').fetchall()
  run.update(http_status=code,task=status,events=ev,files=files,authorizations=auth,attempts=attempts)
  if mode=='normal':
   check('Fresh chat note succeeds with ordered terminal SSE',code==200 and len(files)==1 and names[-2:]==['tool.completed','task.completed'])
   _,calendar=request(port,'/assistant/chat',{'message':'Schedule V02 Study from 2026-11-18T10:00:00 to 2026-11-18T11:00:00'})
   cc={k:calendar['reply']['pending_approval'][k] for k in ['task_id','node_id','proposal_id']}
   code,out=request(port,'/assistant/approve',{**cc,'approved':True})
   with sqlite3.connect(d/'data/nova_calendar.db') as conn:rows=conn.execute('SELECT title FROM calendar_events').fetchall()
   check('Fresh chat calendar executes real SQLite write',code==200 and rows==[('V02 Study',)],rows=rows)
   _,denied=request(port,'/assistant/quick-note',{'title':'Denied','body':'Do not create'})
   dd={k:denied['pending_approval'][k] for k in ['task_id','node_id','proposal_id']}
   code,out=request(port,'/assistant/approve',{**dd,'approved':False})
   check('Fresh quick-note denial is truthful',code==200 and 'denied' in out['workspace']['recent_activity'][0]['what_happened'] and not (d/'workspace/notes/denied.md').exists())
  elif mode=='race':
   check('Revocation between approval and claim blocks write',code==409 and not files)
   check('Revocation after tool.started has terminal lifecycle',('tool.failed' in names or 'permission.denied' in names) and 'task.failed' in names,http_status=code,task_status=status['status'],events=names)
   check('Race rejection is audited',any(row[1]=='revoked' for row in attempts))
  else:
   check('SQLite audit-write failure prevents handler write',not files and auth==[('approved',)],http_status=code,task_status=status['status'])
   check('Audit-write failure is reported as unsuccessful operation',code>=400 or result.get('reply',{}).get('action_category')=='action_failed',http_status=code)
 finally:
  p.terminate();p.wait(timeout=10);log.close();run['exit_code']=p.returncode
with (R/'challenge-results.json').open('x',encoding='utf-8') as f:json.dump({'checks':checks,'runs':runs,'http':records},f,indent=2)
print(json.dumps(checks,indent=2))
